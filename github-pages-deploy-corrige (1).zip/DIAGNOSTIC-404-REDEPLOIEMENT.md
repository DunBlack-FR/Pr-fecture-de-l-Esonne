# Diagnostic 404 et redéploiement — GitHub Pages

Le paquet contient `index.html` à sa racine, ainsi que les fichiers et images locaux requis. Un 404 de l’accueil malgré cela peut provenir d’une source Pages (branche/dossier) différente, d’un déploiement échoué ou en attente, ou d’une URL erronée. Vérifiez également la casse et qu’aucun dossier parent supplémentaire ne sépare `index.html` de la racine publiée. Un 404 d’image/script indique souvent un fichier manquant ou un chemin/casse divergent. Le défaut d’assets localement identifié est couvert par `assets/palais-de-justice.webp` et `assets/tribunal-logo.png`. Sans accès au dépôt et aux réglages distants, la cause du 404 distant ne peut pas être confirmée ni corrigée ici.

## Redéployer

1. Décompressez **le contenu** du ZIP directement à la racine de la branche/dossier choisi pour Pages, en conservant `index.html` et `assets/` à la racine.
2. Dans **Settings → Pages**, vérifiez la branche et le dossier source (`/(root)` si les fichiers sont à la racine, ou `/docs` si vous y avez placé tout le site).
3. Vérifiez dans **Actions/Deployments** que le workflow Pages se termine avec succès, puis utilisez l’URL affichée par GitHub. Attendez le déploiement et rechargez sans cache.
4. Si l’erreur persiste, inspectez l’URL exacte et les requêtes réseau (404/chemins/casse) et comparez-les à l’arborescence publiée.

La configuration Supabase est volontairement fictive et sans secret; Auth et l’administration ne sont pas opérationnelles tant qu’un projet n’est pas configuré et sécurisé. Ne mettez jamais de clé `service_role` dans ce site. Ce contrôle local ne prouve pas que le site distant est corrigé.
