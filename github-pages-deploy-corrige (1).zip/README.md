# Tribunal de Paris — publication GitHub Pages

Ce dossier est publiable comme site statique. **`index.html` est à la racine** et les ressources attendues sont dans `assets/`.

## Publier

1. Committez le contenu de ce dossier à la racine du dépôt GitHub, en conservant exactement les noms et la casse des fichiers.
2. Dans **Settings → Pages**, choisissez **Deploy from a branch**, sélectionnez la branche voulue (par ex. `main`) et le dossier **`/(root)`**, puis enregistrez. Vérifiez que cette branche contient bien `index.html` à sa racine.
3. Attendez la fin du déploiement dans **Actions** / **Deployments**, puis ouvrez l’URL Pages affichée par GitHub. Pour un dépôt de projet, l’URL inclut le nom du dépôt; les liens/assets du site sont relatifs et sont prévus pour ce préfixe.
4. Si vous choisissez plutôt `/docs`, il faut placer **tout le site** dans `/docs` et choisir ce dossier dans Pages. Ne publiez pas seulement le HTML sans CSS, scripts et `assets/`.

## À propos du 404

Dans l’état local vérifié, le point d’entrée existe bien sous le nom exact `index.html` à la racine. Les images étaient en revanche référencées sous `assets/` alors qu’elles étaient auparavant à la racine; elles ont été copiées dans `assets/` pour satisfaire ces références. Ce défaut aurait cassé les images, mais **n’explique pas à lui seul un 404 sur la page d’accueil**. Un 404 à l’URL Pages est donc plus probablement lié au dépôt/à la branche ou au répertoire de publication Pages, à l’absence de déploiement réussi, ou à une URL d’accès erronée. Je n’ai pas accès aux réglages distants du dépôt et ne peux pas les corriger ni confirmer la cause distante.

## Sécurité et limites

`supabase-config.js` contient des valeurs fictives. L’authentification et l’administration ne fonctionneront pas avant une configuration Supabase valide et la préparation/validation serveur décrite dans `SETUP.md`. N’ajoutez jamais de clé `service_role` ni de secret au dépôt ou au navigateur; seuls des paramètres publics sont admissibles côté client. Cette maquette n’est pas un service officiel ou sécurisé : **n’y saisissez et n’y stockez aucune donnée judiciaire réelle** sans validation formelle de sécurité, protection des données, autorisations et procédures opérationnelles. GitHub Pages ne fournit que l’hébergement statique.
